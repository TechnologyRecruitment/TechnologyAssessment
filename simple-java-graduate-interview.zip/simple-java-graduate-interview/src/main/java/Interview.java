public class Interview {
    public int process(int[] input, String operation) {
        return 1;
    }
}
