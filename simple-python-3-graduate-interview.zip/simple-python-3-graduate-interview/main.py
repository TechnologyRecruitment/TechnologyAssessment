import test_main

########
# Candidate to only edit below this line.
########

def process(input, operation):
    return 1