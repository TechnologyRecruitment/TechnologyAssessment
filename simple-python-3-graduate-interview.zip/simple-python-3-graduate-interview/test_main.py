import unittest
import main

#####
# Candidate to only edit below this line.
#####

class Tests(unittest.TestCase):
    def test_1(self):
        self.fail("not yet implemented")



#####
# Candidate to only edit above this line.
#####

if __name__ == '__main__':
    unittest.main()