﻿using System;

namespace Calculator
{
    public class Calculator
    {
        public object DoSomething()
        {
            throw new NotImplementedException();
        }
    }
}
