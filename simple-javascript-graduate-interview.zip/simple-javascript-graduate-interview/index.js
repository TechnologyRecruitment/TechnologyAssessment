const process = (input, operation) => {};

module.exports = process;
